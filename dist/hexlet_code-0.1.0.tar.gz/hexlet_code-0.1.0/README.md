### Hexlet tests and linter status:
[![Actions Status](https://github.com/Lamer-beda/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Lamer-beda/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/6b843db4abbcdbe2420d/maintainability)](https://codeclimate.com/github/Lamer-beda/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/625782.svg)](https://asciinema.org/a/625782)
[![asciicast](https://asciinema.org/a/K5aYrvBHoZoGeB9vQXPvV7oYy.svg)](https://asciinema.org/a/K5aYrvBHoZoGeB9vQXPvV7oYy)
[![asciicast](https://asciinema.org/a/o8QV8OgFrPI1N4BFM8o4ccllb.svg)](https://asciinema.org/a/o8QV8OgFrPI1N4BFM8o4ccllb)
[![asciicast](https://asciinema.org/a/6skNCezUENPjGULFh7BlshvLU.svg)](https://asciinema.org/a/6skNCezUENPjGULFh7BlshvLU)
